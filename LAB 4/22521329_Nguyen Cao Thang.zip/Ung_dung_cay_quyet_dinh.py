import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import plot_tree
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk

# Tính entropy của tập dữ liệu
def calculate_entropy(data, target_attribute):
    total_samples = len(data)
    entropy = 0
    for class_value in data[target_attribute].unique():
        p_class = len(data[data[target_attribute] == class_value]) / total_samples
        if p_class > 0:
            entropy -= p_class * np.log2(p_class)
    return entropy

# Tính hệ số Gain cho từng thuộc tính
def calculate_gain(data, attribute, target_attribute):
    total_entropy = calculate_entropy(data, target_attribute)
    attribute_values = data[attribute].unique()
    weighted_entropy = 0
    for value in attribute_values:
        subset = data[data[attribute] == value]
        weighted_entropy += (len(subset) / len(data)) * calculate_entropy(subset, target_attribute)
    return total_entropy - weighted_entropy

# Tạo cây quyết định ID3
def gain_id3_decision_tree(data, target_attribute):
    if len(data[target_attribute].unique()) == 1:
        return data[target_attribute].unique()[0]
    
    if len(data.columns.drop(target_attribute)) == 0:
        return data[target_attribute].mode()[0]
    
    best_attribute = max(
        data.columns.drop(target_attribute),
        key=lambda attr: calculate_gain(data, attr, target_attribute)
    )
    
    tree = {best_attribute: {}}
    for value in data[best_attribute].unique():
        subset = data[data[best_attribute] == value].drop(columns=[best_attribute])
        tree[best_attribute][value] = gain_id3_decision_tree(subset, target_attribute)
    return tree

# Tính hệ số Gini cho từng thuộc tính
def calculate_gini(data, attribute, target_attribute):
    total_samples = len(data)
    weighted_gini = 0
    
    for value in data[attribute].unique():
        subset = data[data[attribute] == value]
        subset_size = len(subset)
        
        gini = 1
        for class_value in subset[target_attribute].unique():
            p = len(subset[subset[target_attribute] == class_value]) / subset_size
            gini -= p ** 2
        
        weighted_gini += (subset_size / total_samples) * gini

    return weighted_gini

# Tạo cây quyết định ID3 
def gini_id3_decision_tree(data, target_attribute):
    if len(data[target_attribute].unique()) == 1:
        return data[target_attribute].unique()[0]
    
    if len(data.columns.drop(target_attribute)) == 0:
        return data[target_attribute].mode()[0]
    
    best_attribute = min(
        data.columns.drop(target_attribute),
        key=lambda attr: calculate_gini(data, attr, target_attribute)
    )
    
    tree = {best_attribute: {}}
    for value in data[best_attribute].unique():
        subset = data[data[best_attribute] == value].drop(columns=[best_attribute])
        
        if subset.empty:
            tree[best_attribute][value] = data[target_attribute].mode()[0]
        else:
            tree[best_attribute][value] = gini_id3_decision_tree(subset, target_attribute)
    return tree

# Vẽ cây quyết định
def visualize_tree(tree, parent_name="", level=0):
    plt.figure(figsize=(15, 10))
    
    def plot_node(tree, parent_pos, current_pos, level):
        if isinstance(tree, dict):
            attribute = list(tree.keys())[0]
            plt.plot([parent_pos[0], current_pos[0]], [parent_pos[1], current_pos[1]], 'k-')
            plt.text(current_pos[0], current_pos[1], attribute, 
                    bbox=dict(facecolor='white', edgecolor='black'),
                    ha='center', va='center')
            
            num_children = len(tree[attribute])
            width = 2.0 / (2 ** level)
            
            for i, (value, subtree) in enumerate(tree[attribute].items()):
                child_x = current_pos[0] - width/2 + (i+0.5)*width/num_children
                child_y = current_pos[1] - 1
                child_pos = (child_x, child_y)
                
                # Draw edge label
                mid_x = (current_pos[0] + child_x) / 2
                mid_y = (current_pos[1] + child_y) / 2
                plt.text(mid_x, mid_y, str(value), ha='center', va='center')
                
                plot_node(subtree, current_pos, child_pos, level+1)
        else:
            plt.plot([parent_pos[0], current_pos[0]], [parent_pos[1], current_pos[1]], 'k-')
            plt.text(current_pos[0], current_pos[1], str(tree),
                    bbox=dict(facecolor='lightgreen', edgecolor='black'),
                    ha='center', va='center')

    root_pos = (0, 0)
    plot_node(tree, root_pos, root_pos, 1)
    
    plt.axis('off')
    plt.show()
    
# Tạo luật từ cây quyết định
def extract_rules(tree, target_attribute, current_rule=None, rules=None):
    if rules is None:
        rules = []
    if current_rule is None:
        current_rule = []

    if not isinstance(tree, dict):
        # Đến lá: thêm luật hoàn chỉnh
        rule = "IF " + " AND ".join(current_rule) + f" THEN {target_attribute} = {tree}"
        rules.append(rule)
        return rules

    # Duyệt qua các nhánh
    attribute = next(iter(tree))
    for value, subtree in tree[attribute].items():
        condition = f"{attribute} = {value}"
        extract_rules(subtree, target_attribute, current_rule + [condition], rules)

    return rules

class DecisionTreeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Decision Tree Builder")
        
        # Set specific window size
        window_width = 1200
        window_height = 800
        
        # Center the window
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        
        # Load and set background image
        try:
            self.bg_image = Image.open("background.jpg")
            # Resize image to fit window
            self.bg_image = self.bg_image.resize((window_width, window_height), Image.Resampling.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(self.bg_image)
            
            # Create canvas for background
            self.canvas = tk.Canvas(root, width=window_width, height=window_height)
            self.canvas.pack(fill="both", expand=True)
            self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")
            
            # Create main frame with transparent background
            self.main_frame = tk.Frame(self.canvas, bg='')
            self.main_frame.place(relx=0.5, rely=0.5, anchor="center")
            
        except Exception as e:
            messagebox.showerror("Error", f"Không thể tải hình nền: {str(e)}")
            # Fallback to normal frame if background fails
            self.main_frame = tk.Frame(root, padx=20, pady=20)
            self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.data = None
        self.target_attribute = None
        
        # File selection
        self.file_frame = tk.LabelFrame(self.main_frame, text="Chọn File", padx=10, pady=10, bg='white')
        self.file_frame.pack(fill=tk.X, pady=5)
        
        # First column option
        self.eliminate_first_col = tk.BooleanVar(value=False)
        self.first_col_checkbox = tk.Checkbutton(self.file_frame, text="Không quan tâm cột đầu tiên trong bảng", 
                                                variable=self.eliminate_first_col, bg='white')
        self.first_col_checkbox.pack(side=tk.LEFT, padx=5)
        
        self.file_path = tk.StringVar()
        self.file_entry = tk.Entry(self.file_frame, textvariable=self.file_path, width=50, bg='white')
        self.file_entry.pack(side=tk.LEFT, padx=5)
        
        self.browse_button = tk.Button(self.file_frame, text="Browse", command=self.browse_file, bg='white')
        self.browse_button.pack(side=tk.LEFT, padx=5)
        
        # Target attribute selection
        self.target_frame = tk.LabelFrame(self.main_frame, text="Thuộc tính quyết định", padx=10, pady=10, bg='white')
        self.target_frame.pack(fill=tk.X, pady=5)
        
        self.target_var = tk.StringVar()
        self.target_dropdown = tk.OptionMenu(self.target_frame, self.target_var, "")
        self.target_dropdown.config(bg='white')
        self.target_dropdown.pack(side=tk.LEFT, padx=5)
        
        # Tree type selection
        self.tree_frame = tk.LabelFrame(self.main_frame, text="Cách tính hệ số", padx=10, pady=10, bg='white')
        self.tree_frame.pack(fill=tk.X, pady=5)
        
        self.tree_type = tk.StringVar(value="gain")
        tk.Radiobutton(self.tree_frame, text="Gain", variable=self.tree_type, value="gain", bg='white').pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(self.tree_frame, text="Gini", variable=self.tree_type, value="gini", bg='white').pack(side=tk.LEFT, padx=5)
        
        # Buttons
        self.build_button = tk.Button(self.main_frame, text="Tạo cây quyết định", command=self.build_tree, bg='white')
        self.build_button.pack(pady=10)
        
        self.extract_rules_button = tk.Button(self.main_frame, text="Trích xuất luật", command=self.extract_rules_only, bg='white')
        self.extract_rules_button.pack(pady=5)
        
        self.show_calc_button = tk.Button(self.main_frame, text="Hiển thị tính toán", command=self.show_calculations, bg='white')
        self.show_calc_button.pack(pady=5)
        
        # Calculations display
        self.calc_frame = tk.LabelFrame(self.main_frame, text="Kết quả tính toán", padx=10, pady=10, bg='white')
        self.calc_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.calc_text = tk.Text(self.calc_frame, wrap=tk.WORD, height=10, bg='white')
        self.calc_text.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar for calculations
        self.calc_scrollbar = tk.Scrollbar(self.calc_text)
        self.calc_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.calc_text.config(yscrollcommand=self.calc_scrollbar.set)
        self.calc_scrollbar.config(command=self.calc_text.yview)
        
        # Rules display
        self.rules_frame = tk.LabelFrame(self.main_frame, text="Bộ luật quyết định", padx=10, pady=10, bg='white')
        self.rules_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.rules_text = tk.Text(self.rules_frame, wrap=tk.WORD, height=10, bg='white')
        self.rules_text.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar for rules
        self.scrollbar = tk.Scrollbar(self.rules_text)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.rules_text.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.rules_text.yview)
    
    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.file_path.set(file_path)
            self.load_data()
    
    def load_data(self):
        try:
            self.data = pd.read_csv(self.file_path.get())
            
            # Eliminate first column if checkbox is checked
            if self.eliminate_first_col.get() and len(self.data.columns) > 0:
                self.data = self.data.iloc[:, 1:]
            
            # Update target attribute dropdown
            menu = self.target_dropdown["menu"]
            menu.delete(0, "end")
            for column in self.data.columns:
                menu.add_command(label=column, command=lambda value=column: self.target_var.set(value))
            if self.data.columns.size > 0:
                self.target_var.set(self.data.columns[0])
        except Exception as e:
            messagebox.showerror("Error", f"Error loading file: {str(e)}")
    
    def extract_rules_only(self):
        if self.data is None:
            messagebox.showerror("Error", "Vui lòng tải file CSV trước")
            return
        
        if not self.target_var.get():
            messagebox.showerror("Error", "Vui lòng chọn thuộc tính quyết định")
            return
        
        try:
            # Build tree based on selected type
            if self.tree_type.get() == "gain":
                tree = gain_id3_decision_tree(self.data, self.target_var.get())
            else:
                tree = gini_id3_decision_tree(self.data, self.target_var.get())
            
            # Extract and display rules
            rules = extract_rules(tree, self.target_var.get())
            self.rules_text.delete(1.0, tk.END)
            for rule in rules:
                self.rules_text.insert(tk.END, rule + "\n\n")
            
        except Exception as e:
            messagebox.showerror("Error", f"Lỗi khi trích xuất luật: {str(e)}")

    def show_calculations(self):
        if self.data is None:
            messagebox.showerror("Error", "Vui lòng tải file CSV trước")
            return
        
        if not self.target_var.get():
            messagebox.showerror("Error", "Vui lòng chọn thuộc tính quyết định")
            return
        
        try:
            self.calc_text.delete(1.0, tk.END)
            target = self.target_var.get()
            
            # Calculate for each attribute
            for attribute in self.data.columns.drop(target):
                if self.tree_type.get() == "gain":
                    # Calculate entropy and gain
                    total_entropy = calculate_entropy(self.data, target)
                    gain = calculate_gain(self.data, attribute, target)
                    
                    self.calc_text.insert(tk.END, f"Thuộc tính: {attribute}\n")
                    self.calc_text.insert(tk.END, f"Entropy tổng: {total_entropy:.4f}\n")
                    
                    # Calculate entropy for each value
                    for value in self.data[attribute].unique():
                        subset = self.data[self.data[attribute] == value]
                        subset_entropy = calculate_entropy(subset, target)
                        self.calc_text.insert(tk.END, f"  Entropy khi {attribute} = {value}: {subset_entropy:.4f}\n")
                    
                    self.calc_text.insert(tk.END, f"Gain: {gain:.4f}\n\n")
                else:
                    # Calculate Gini
                    gini = calculate_gini(self.data, attribute, target)
                    self.calc_text.insert(tk.END, f"Thuộc tính: {attribute}\n")
                    self.calc_text.insert(tk.END, f"Hệ số Gini: {gini:.4f}\n\n")
            
        except Exception as e:
            messagebox.showerror("Error", f"Lỗi khi tính toán: {str(e)}")

    def build_tree(self):
        if self.data is None:
            messagebox.showerror("Error", "Vui lòng tải file CSV trước")
            return
        
        if not self.target_var.get():
            messagebox.showerror("Error", "Vui lòng chọn thuộc tính quyết định")
            return
        
        try:
            # Build tree based on selected type
            if self.tree_type.get() == "gain":
                tree = gain_id3_decision_tree(self.data, self.target_var.get())
            else:
                tree = gini_id3_decision_tree(self.data, self.target_var.get())
            
            # Visualize tree
            visualize_tree(tree)
            
        except Exception as e:
            messagebox.showerror("Error", f"Lỗi khi tạo cây: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = DecisionTreeApp(root)
    root.mainloop()
